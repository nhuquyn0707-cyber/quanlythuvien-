package com.library.view;

import com.library.dao.*;
import com.library.entity.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MuonTraPanel extends JPanel {
    private JTextField txtMaPhieu, txtNgayHenTra;
    private JComboBox<DocGia> cbDocGia;
    private JComboBox<NhanVien> cbNhanVien;
    private JComboBox<Sach> cbSach;
    private JTable table;
    private DefaultTableModel model;
    private PhieuMuonDAO pmDAO = new PhieuMuonDAO();
    private DocGiaDAO dgDAO = new DocGiaDAO();
    private SachDAO sachDAO = new SachDAO();
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    public MuonTraPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel form = new JPanel(new GridLayout(3, 4, 10, 10));
        txtMaPhieu = new JTextField();
        txtNgayHenTra = new JTextField("2026-11-25");
        cbDocGia = new JComboBox<>();
        cbNhanVien = new JComboBox<>();
        cbSach = new JComboBox<>();

        for (DocGia dg : dgDAO.getAll()) cbDocGia.addItem(dg);
        for (NhanVien nv : dgDAO.getAllNhanVien()) cbNhanVien.addItem(nv);
        for (Sach s : sachDAO.getAll()) cbSach.addItem(s);

        form.add(new JLabel("Mã Phiếu Mượn:")); form.add(txtMaPhieu);
        form.add(new JLabel("Độc Giả:")); form.add(cbDocGia);
        form.add(new JLabel("Nhân Viên Lập:")); form.add(cbNhanVien);
        form.add(new JLabel("Chọn Sách:")); form.add(cbSach);
        form.add(new JLabel("Ngày Hẹn Trả (yyyy-MM-dd):")); form.add(txtNgayHenTra);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnMuon = new JButton("Lập Phiếu Mượn");
        JButton btnTra = new JButton("Xác Nhận Trả Sách Đang Chọn");
        JButton btnRefresh = new JButton("Tải Lại Danh Sách");
        btns.add(btnMuon); btns.add(btnTra); btns.add(btnRefresh);

        JPanel top = new JPanel(new BorderLayout());
        top.add(form, BorderLayout.CENTER);
        top.add(btns, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"Mã Phiếu", "Mã Sách", "Tên Sách", "Độc Giả", "Ngày Hẹn Trả", "Ngày Trả Thực Tế", "Trạng Thái", "Tiền Phạt"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadData();

        btnMuon.addActionListener(e -> {
            try {
                PhieuMuon pm = new PhieuMuon();
                pm.setMaPhieu(txtMaPhieu.getText().trim());
                pm.setDocGia((DocGia) cbDocGia.getSelectedItem());
                pm.setNhanVien((NhanVien) cbNhanVien.getSelectedItem());
                pm.setNgayMuon(new Date());

                Sach s = (Sach) cbSach.getSelectedItem();
                ChiTietPhieuMuon ct = new ChiTietPhieuMuon();
                ct.setId(new ChiTietPhieuMuonId(pm.getMaPhieu(), s.getMaSach()));
                ct.setPhieuMuon(pm);
                ct.setSach(s);
                ct.setNgayHenTra(sdf.parse(txtNgayHenTra.getText().trim()));
                ct.setTrangThai("Đang mượn");

                if (pmDAO.muonSach(pm, ct)) {
                    JOptionPane.showMessageDialog(this, "Mượn sách thành công! Đã trừ tồn kho.");
                    loadData();
                } else {
                    JOptionPane.showMessageDialog(this, "Không thể mượn (Hết sách hoặc trùng mã phiếu)!");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Vui lòng kiểm tra lại dữ liệu nhập!");
            }
        });

        btnTra.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r < 0) {
                JOptionPane.showMessageDialog(this, "Chọn một dòng trên bảng để trả sách!");
                return;
            }
            String maPhieu = model.getValueAt(r, 0).toString();
            String maSach = model.getValueAt(r, 1).toString();
            if (pmDAO.traSach(maPhieu, maSach)) {
                JOptionPane.showMessageDialog(this, "Trả sách thành công! Đã cập nhật kho và tính phí phạt (nếu có).");
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, "Sách này đã được trả trước đó!");
            }
        });

        btnRefresh.addActionListener(e -> loadData());
    }

    private void loadData() {
        model.setRowCount(0);
        for (ChiTietPhieuMuon ct : pmDAO.getAllChiTiet()) {
            model.addRow(new Object[]{
                ct.getId().getMaPhieu(),
                ct.getId().getMaSach(),
                ct.getSach().getTenSach(),
                ct.getPhieuMuon().getDocGia().getHoTen(),
                ct.getNgayHenTra(),
                ct.getNgayTraThucTe(),
                ct.getTrangThai(),
                ct.getTienPhat()
            });
        }
    }
}
