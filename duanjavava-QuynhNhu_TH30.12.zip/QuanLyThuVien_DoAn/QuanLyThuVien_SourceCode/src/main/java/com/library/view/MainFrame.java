package com.library.view;

import javax.swing.*;

public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("HỆ THỐNG QUẢN LÝ THƯ VIỆN - JAVA SWING & HIBERNATE");
        setSize(1000, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Quản Lý Sách", new QuanLySachPanel());
        tabs.addTab("Quản Lý Độc Giả", new QuanLyDocGiaPanel());
        tabs.addTab("Mượn / Trả Sách", new MuonTraPanel());
        tabs.addTab("Thống Kê & Báo Cáo", new ThongKePanel());

        add(tabs);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
