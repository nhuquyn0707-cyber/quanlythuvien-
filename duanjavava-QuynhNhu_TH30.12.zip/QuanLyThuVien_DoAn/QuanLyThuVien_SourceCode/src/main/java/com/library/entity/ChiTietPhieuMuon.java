package com.library.entity;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "ChiTietPhieuMuon")
public class ChiTietPhieuMuon {
    @EmbeddedId
    private ChiTietPhieuMuonId id;

    @ManyToOne(fetch = FetchType.EAGER)
    @MapsId("maPhieu")
    @JoinColumn(name = "MaPhieu")
    private PhieuMuon phieuMuon;

    @ManyToOne(fetch = FetchType.EAGER)
    @MapsId("maSach")
    @JoinColumn(name = "MaSach")
    private Sach sach;

    @Temporal(TemporalType.DATE)
    @Column(name = "NgayHenTra", nullable = false)
    private Date ngayHenTra;

    @Temporal(TemporalType.DATE)
    @Column(name = "NgayTraThucTe")
    private Date ngayTraThucTe;

    @Column(name = "TrangThai", length = 30)
    private String trangThai = "Đang mượn";

    @Column(name = "TienPhat", precision = 18, scale = 2)
    private BigDecimal tienPhat = BigDecimal.ZERO;

    public ChiTietPhieuMuon() {}

    public ChiTietPhieuMuonId getId() { return id; }
    public void setId(ChiTietPhieuMuonId id) { this.id = id; }
    public PhieuMuon getPhieuMuon() { return phieuMuon; }
    public void setPhieuMuon(PhieuMuon phieuMuon) { this.phieuMuon = phieuMuon; }
    public Sach getSach() { return sach; }
    public void setSach(Sach sach) { this.sach = sach; }
    public Date getNgayHenTra() { return ngayHenTra; }
    public void setNgayHenTra(Date ngayHenTra) { this.ngayHenTra = ngayHenTra; }
    public Date getNgayTraThucTe() { return ngayTraThucTe; }
    public void setNgayTraThucTe(Date ngayTraThucTe) { this.ngayTraThucTe = ngayTraThucTe; }
    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }
    public BigDecimal getTienPhat() { return tienPhat; }
    public void setTienPhat(BigDecimal tienPhat) { this.tienPhat = tienPhat; }
}
