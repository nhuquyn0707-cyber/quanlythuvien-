package com.library.view;

import com.library.dao.DocGiaDAO;
import com.library.entity.DocGia;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;

public class QuanLyDocGiaPanel extends JPanel {
    private JTextField txtMa, txtTen, txtNgaySinh, txtDiaChi, txtSDT, txtHetHan, txtTim;
    private JTable table;
    private DefaultTableModel model;
    private DocGiaDAO dao = new DocGiaDAO();
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    public QuanLyDocGiaPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel form = new JPanel(new GridLayout(3, 4, 10, 10));
        txtMa = new JTextField(); txtTen = new JTextField();
        txtNgaySinh = new JTextField("2004-01-01"); txtDiaChi = new JTextField();
        txtSDT = new JTextField(); txtHetHan = new JTextField("2027-12-31");

        form.add(new JLabel("Mã Độc Giả:")); form.add(txtMa);
        form.add(new JLabel("Họ Tên:")); form.add(txtTen);
        form.add(new JLabel("Ngày Sinh (yyyy-MM-dd):")); form.add(txtNgaySinh);
        form.add(new JLabel("Địa Chỉ:")); form.add(txtDiaChi);
        form.add(new JLabel("Số Điện Thoại:")); form.add(txtSDT);
        form.add(new JLabel("Ngày Hết Hạn (yyyy-MM-dd):")); form.add(txtHetHan);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnLuu = new JButton("Thêm / Cập Nhật");
        JButton btnXoa = new JButton("Xóa");
        txtTim = new JTextField(15);
        JButton btnTim = new JButton("Tìm Kiếm");
        btns.add(btnLuu); btns.add(btnXoa); btns.add(new JLabel("  Tìm tên/SĐT:")); btns.add(txtTim); btns.add(btnTim);

        JPanel top = new JPanel(new BorderLayout());
        top.add(form, BorderLayout.CENTER);
        top.add(btns, BorderLayout.SOUTH);
        add(top, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"Mã ĐG", "Họ Tên", "Ngày Sinh", "Địa Chỉ", "SĐT", "Ngày Tạo", "Ngày Hết Hạn"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadData(dao.getAll());

        table.getSelectionModel().addListSelectionListener(e -> {
            int r = table.getSelectedRow();
            if (r >= 0) {
                txtMa.setText(model.getValueAt(r, 0).toString());
                txtTen.setText(model.getValueAt(r, 1).toString());
                txtNgaySinh.setText(String.valueOf(model.getValueAt(r, 2)));
                txtDiaChi.setText(String.valueOf(model.getValueAt(r, 3)));
                txtSDT.setText(String.valueOf(model.getValueAt(r, 4)));
                txtHetHan.setText(String.valueOf(model.getValueAt(r, 6)));
            }
        });

        btnLuu.addActionListener(e -> {
            try {
                DocGia dg = new DocGia();
                dg.setMaDG(txtMa.getText().trim());
                dg.setHoTen(txtTen.getText().trim());
                dg.setNgaySinh(sdf.parse(txtNgaySinh.getText().trim()));
                dg.setDiaChi(txtDiaChi.getText().trim());
                dg.setSoDienThoai(txtSDT.getText().trim());
                dg.setNgayHetHan(sdf.parse(txtHetHan.getText().trim()));
                if (dao.saveOrUpdate(dg)) {
                    JOptionPane.showMessageDialog(this, "Lưu độc giả thành công!");
                    loadData(dao.getAll());
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Lỗi định dạng ngày hoặc trùng SĐT!");
            }
        });

        btnXoa.addActionListener(e -> {
            if (dao.delete(txtMa.getText().trim())) {
                JOptionPane.showMessageDialog(this, "Đã xóa độc giả!");
                loadData(dao.getAll());
            }
        });

        btnTim.addActionListener(e -> loadData(dao.search(txtTim.getText().trim())));
    }

    private void loadData(List<DocGia> list) {
        model.setRowCount(0);
        for (DocGia d : list) {
            model.addRow(new Object[]{d.getMaDG(), d.getHoTen(), d.getNgaySinh(), d.getDiaChi(), d.getSoDienThoai(), d.getNgayTaoThe(), d.getNgayHetHan()});
        }
    }
}
