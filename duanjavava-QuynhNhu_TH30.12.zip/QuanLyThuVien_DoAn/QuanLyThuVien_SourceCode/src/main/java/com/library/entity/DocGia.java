package com.library.entity;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "DocGia")
public class DocGia {
    @Id
    @Column(name = "MaDG", length = 10)
    private String maDG;

    @Column(name = "HoTen", nullable = false, length = 100)
    private String hoTen;

    @Temporal(TemporalType.DATE)
    @Column(name = "NgaySinh")
    private Date ngaySinh;

    @Column(name = "DiaChi", length = 200)
    private String diaChi;

    @Column(name = "SoDienThoai", unique = true, length = 15)
    private String soDienThoai;

    @Temporal(TemporalType.DATE)
    @Column(name = "NgayTaoThe")
    private Date ngayTaoThe = new Date();

    @Temporal(TemporalType.DATE)
    @Column(name = "NgayHetHan", nullable = false)
    private Date ngayHetHan;

    @OneToMany(mappedBy = "docGia", cascade = CascadeType.ALL)
    private List<PhieuMuon> dsPhieuMuon;

    public DocGia() {}

    public String getMaDG() { return maDG; }
    public void setMaDG(String maDG) { this.maDG = maDG; }
    public String getHoTen() { return hoTen; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }
    public Date getNgaySinh() { return ngaySinh; }
    public void setNgaySinh(Date ngaySinh) { this.ngaySinh = ngaySinh; }
    public String getDiaChi() { return diaChi; }
    public void setDiaChi(String diaChi) { this.diaChi = diaChi; }
    public String getSoDienThoai() { return soDienThoai; }
    public void setSoDienThoai(String soDienThoai) { this.soDienThoai = soDienThoai; }
    public Date getNgayTaoThe() { return ngayTaoThe; }
    public void setNgayTaoThe(Date ngayTaoThe) { this.ngayTaoThe = ngayTaoThe; }
    public Date getNgayHetHan() { return ngayHetHan; }
    public void setNgayHetHan(Date ngayHetHan) { this.ngayHetHan = ngayHetHan; }

    @Override
    public String toString() { return maDG + " - " + hoTen; }
}
