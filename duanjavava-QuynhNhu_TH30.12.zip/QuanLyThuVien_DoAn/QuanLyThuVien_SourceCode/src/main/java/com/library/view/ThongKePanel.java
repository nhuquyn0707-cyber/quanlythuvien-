package com.library.view;

import com.library.dao.*;
import com.library.entity.*;
import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class ThongKePanel extends JPanel {
    private JLabel lblTongSach, lblDangMuon, lblQuaHan, lblTienPhat;
    private SachDAO sachDAO = new SachDAO();
    private PhieuMuonDAO pmDAO = new PhieuMuonDAO();

    public ThongKePanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel grid = new JPanel(new GridLayout(2, 2, 20, 20));
        lblTongSach = createCard("TỔNG SỐ SÁCH TRONG KHO");
        lblDangMuon = createCard("SÁCH ĐANG ĐƯỢC MƯỢN");
        lblQuaHan = createCard("PHIẾU MƯỢN QUÁ HẠN");
        lblTienPhat = createCard("TỔNG DOANH THU TIỀN PHẠT");

        grid.add(lblTongSach); grid.add(lblDangMuon);
        grid.add(lblQuaHan); grid.add(lblTienPhat);
        add(grid, BorderLayout.CENTER);

        JButton btnCapNhat = new JButton("Cập Nhật Số Liệu Thống Kê");
        add(btnCapNhat, BorderLayout.SOUTH);

        tinhToan();
        btnCapNhat.addActionListener(e -> tinhToan());
    }

    private JLabel createCard(String title) {
        JLabel lbl = new JLabel(title, SwingConstants.CENTER);
        lbl.setFont(new Font("Arial", Font.BOLD, 16));
        lbl.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
        return lbl;
    }

    private void tinhToan() {
        int tongTon = sachDAO.getAll().stream().mapToInt(Sach::getSoLuongTon).sum();
        List<ChiTietPhieuMuon> list = pmDAO.getAllChiTiet();
        long dangMuon = list.stream().filter(c -> "Đang mượn".equals(c.getTrangThai())).count();
        long quaHan = list.stream().filter(c -> "Đang mượn".equals(c.getTrangThai()) && new Date().after(c.getNgayHenTra())).count();
        BigDecimal tongPhat = list.stream().map(ChiTietPhieuMuon::getTienPhat).reduce(BigDecimal.ZERO, BigDecimal::add);

        lblTongSach.setText("<html><center>TỔNG SÁCH TỒN KHO<br><br><font size='6' color='blue'>" + tongTon + " cuốn</font></center></html>");
        lblDangMuon.setText("<html><center>SÁCH ĐANG MƯỢN<br><br><font size='6' color='orange'>" + dangMuon + " lượt</font></center></html>");
        lblQuaHan.setText("<html><center>SÁCH QUÁ HẠN CHƯA TRẢ<br><br><font size='6' color='red'>" + quaHan + " lượt</font></center></html>");
        lblTienPhat.setText("<html><center>TỔNG TIỀN PHẠT THU ĐƯỢC<br><br><font size='6' color='green'>" + tongPhat + " VNĐ</font></center></html>");
    }
}
