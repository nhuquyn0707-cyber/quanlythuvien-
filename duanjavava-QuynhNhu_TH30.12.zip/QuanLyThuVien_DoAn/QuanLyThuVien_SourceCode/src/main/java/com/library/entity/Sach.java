package com.library.entity;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "Sach")
public class Sach {
    @Id
    @Column(name = "MaSach", length = 10)
    private String maSach;

    @Column(name = "TenSach", nullable = false, length = 200)
    private String tenSach;

    @Column(name = "TacGia", nullable = false, length = 100)
    private String tacGia;

    @Column(name = "TheLoai", length = 50)
    private String theLoai;

    @Column(name = "NhaXuatBan", length = 100)
    private String nhaXuatBan;

    @Column(name = "NamXuatBan")
    private Integer namXuatBan;

    @Column(name = "SoLuongTon")
    private Integer soLuongTon = 0;

    @Column(name = "DonGia", precision = 18, scale = 2)
    private BigDecimal donGia;

    public Sach() {}

    public String getMaSach() { return maSach; }
    public void setMaSach(String maSach) { this.maSach = maSach; }
    public String getTenSach() { return tenSach; }
    public void setTenSach(String tenSach) { this.tenSach = tenSach; }
    public String getTacGia() { return tacGia; }
    public void setTacGia(String tacGia) { this.tacGia = tacGia; }
    public String getTheLoai() { return theLoai; }
    public void setTheLoai(String theLoai) { this.theLoai = theLoai; }
    public String getNhaXuatBan() { return nhaXuatBan; }
    public void setNhaXuatBan(String nhaXuatBan) { this.nhaXuatBan = nhaXuatBan; }
    public Integer getNamXuatBan() { return namXuatBan; }
    public void setNamXuatBan(Integer namXuatBan) { this.namXuatBan = namXuatBan; }
    public Integer getSoLuongTon() { return soLuongTon; }
    public void setSoLuongTon(Integer soLuongTon) { this.soLuongTon = soLuongTon; }
    public BigDecimal getDonGia() { return donGia; }
    public void setDonGia(BigDecimal donGia) { this.donGia = donGia; }

    @Override
    public String toString() { return maSach + " - " + tenSach; }
}
