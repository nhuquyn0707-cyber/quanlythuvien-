package com.library.entity;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "NhanVien")
public class NhanVien {
    @Id
    @Column(name = "MaNV", length = 10)
    private String maNV;

    @Column(name = "HoTen", nullable = false, length = 100)
    private String hoTen;

    @Temporal(TemporalType.DATE)
    @Column(name = "NgaySinh")
    private Date ngaySinh;

    @Column(name = "SoDienThoai", unique = true, nullable = false, length = 15)
    private String soDienThoai;

    @Column(name = "Email", unique = true, length = 100)
    private String email;

    @Column(name = "ChucVu", nullable = false, length = 50)
    private String chucVu;

    @OneToMany(mappedBy = "nhanVien", cascade = CascadeType.ALL)
    private List<PhieuMuon> dsPhieuMuon;

    public NhanVien() {}

    public String getMaNV() { return maNV; }
    public void setMaNV(String maNV) { this.maNV = maNV; }
    public String getHoTen() { return hoTen; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }
    public Date getNgaySinh() { return ngaySinh; }
    public void setNgaySinh(Date ngaySinh) { this.ngaySinh = ngaySinh; }
    public String getSoDienThoai() { return soDienThoai; }
    public void setSoDienThoai(String soDienThoai) { this.soDienThoai = soDienThoai; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getChucVu() { return chucVu; }
    public void setChucVu(String chucVu) { this.chucVu = chucVu; }
    public List<PhieuMuon> getDsPhieuMuon() { return dsPhieuMuon; }
    public void setDsPhieuMuon(List<PhieuMuon> dsPhieuMuon) { this.dsPhieuMuon = dsPhieuMuon; }

    @Override
    public String toString() { return maNV + " - " + hoTen; }
}
