package com.library.view;

import com.library.dao.SachDAO;
import com.library.entity.Sach;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

public class QuanLySachPanel extends JPanel {
    private JTextField txtMa, txtTen, txtTacGia, txtTheLoai, txtNXB, txtNam, txtSoLuong, txtDonGia, txtTim;
    private JTable table;
    private DefaultTableModel model;
    private SachDAO sachDAO = new SachDAO();

    public QuanLySachPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel formPanel = new JPanel(new GridLayout(4, 4, 10, 10));
        txtMa = new JTextField(); txtTen = new JTextField();
        txtTacGia = new JTextField(); txtTheLoai = new JTextField();
        txtNXB = new JTextField(); txtNam = new JTextField();
        txtSoLuong = new JTextField(); txtDonGia = new JTextField();

        formPanel.add(new JLabel("Mã Sách:")); formPanel.add(txtMa);
        formPanel.add(new JLabel("Tên Sách:")); formPanel.add(txtTen);
        formPanel.add(new JLabel("Tác Giả:")); formPanel.add(txtTacGia);
        formPanel.add(new JLabel("Thể Loại:")); formPanel.add(txtTheLoai);
        formPanel.add(new JLabel("Nhà Xuất Bản:")); formPanel.add(txtNXB);
        formPanel.add(new JLabel("Năm XB:")); formPanel.add(txtNam);
        formPanel.add(new JLabel("Số Lượng Tồn:")); formPanel.add(txtSoLuong);
        formPanel.add(new JLabel("Đơn Giá:")); formPanel.add(txtDonGia);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnLuu = new JButton("Thêm / Cập Nhật");
        JButton btnXoa = new JButton("Xóa");
        JButton btnLamMoi = new JButton("Làm Mới");
        txtTim = new JTextField(15);
        JButton btnTim = new JButton("Tìm Kiếm");

        btnPanel.add(btnLuu); btnPanel.add(btnXoa); btnPanel.add(btnLamMoi);
        btnPanel.add(new JLabel("   Từ khóa:")); btnPanel.add(txtTim); btnPanel.add(btnTim);

        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(formPanel, BorderLayout.CENTER);
        topPanel.add(btnPanel, BorderLayout.SOUTH);
        add(topPanel, BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"Mã Sách", "Tên Sách", "Tác Giả", "Thể Loại", "NXB", "Năm XB", "Tồn Kho", "Đơn Giá"}, 0);
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        loadData(sachDAO.getAll());

        table.getSelectionModel().addListSelectionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                txtMa.setText(model.getValueAt(row, 0).toString());
                txtTen.setText(model.getValueAt(row, 1).toString());
                txtTacGia.setText(model.getValueAt(row, 2).toString());
                txtTheLoai.setText(String.valueOf(model.getValueAt(row, 3)));
                txtNXB.setText(String.valueOf(model.getValueAt(row, 4)));
                txtNam.setText(String.valueOf(model.getValueAt(row, 5)));
                txtSoLuong.setText(String.valueOf(model.getValueAt(row, 6)));
                txtDonGia.setText(String.valueOf(model.getValueAt(row, 7)));
            }
        });

        btnLuu.addActionListener(e -> {
            try {
                if (txtMa.getText().trim().isEmpty() || txtTen.getText().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ Mã và Tên sách!");
                    return;
                }
                Sach s = new Sach();
                s.setMaSach(txtMa.getText().trim());
                s.setTenSach(txtTen.getText().trim());
                s.setTacGia(txtTacGia.getText().trim());
                s.setTheLoai(txtTheLoai.getText().trim());
                s.setNhaXuatBan(txtNXB.getText().trim());
                s.setNamXuatBan(Integer.parseInt(txtNam.getText().trim()));
                s.setSoLuongTon(Integer.parseInt(txtSoLuong.getText().trim()));
                s.setDonGia(new BigDecimal(txtDonGia.getText().trim()));
                if (sachDAO.saveOrUpdate(s)) {
                    JOptionPane.showMessageDialog(this, "Lưu sách thành công!");
                    loadData(sachDAO.getAll());
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Dữ liệu số không hợp lệ!");
            }
        });

        btnXoa.addActionListener(e -> {
            String ma = txtMa.getText().trim();
            if (!ma.isEmpty() && sachDAO.delete(ma)) {
                JOptionPane.showMessageDialog(this, "Đã xóa sách!");
                loadData(sachDAO.getAll());
            }
        });

        btnTim.addActionListener(e -> loadData(sachDAO.search(txtTim.getText().trim())));
        btnLamMoi.addActionListener(e -> {
            txtMa.setText(""); txtTen.setText(""); txtTacGia.setText("");
            txtTheLoai.setText(""); txtNXB.setText(""); txtNam.setText("");
            txtSoLuong.setText(""); txtDonGia.setText("");
            loadData(sachDAO.getAll());
        });
    }

    private void loadData(List<Sach> list) {
        model.setRowCount(0);
        for (Sach s : list) {
            model.addRow(new Object[]{s.getMaSach(), s.getTenSach(), s.getTacGia(), s.getTheLoai(), s.getNhaXuatBan(), s.getNamXuatBan(), s.getSoLuongTon(), s.getDonGia()});
        }
    }
}
