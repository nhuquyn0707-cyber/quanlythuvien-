package com.library.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class ChiTietPhieuMuonId implements Serializable {
    @Column(name = "MaPhieu", length = 10)
    private String maPhieu;

    @Column(name = "MaSach", length = 10)
    private String maSach;

    public ChiTietPhieuMuonId() {}

    public ChiTietPhieuMuonId(String maPhieu, String maSach) {
        this.maPhieu = maPhieu;
        this.maSach = maSach;
    }

    public String getMaPhieu() { return maPhieu; }
    public void setMaPhieu(String maPhieu) { this.maPhieu = maPhieu; }
    public String getMaSach() { return maSach; }
    public void setMaSach(String maSach) { this.maSach = maSach; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ChiTietPhieuMuonId)) return false;
        ChiTietPhieuMuonId that = (ChiTietPhieuMuonId) o;
        return Objects.equals(maPhieu, that.maPhieu) && Objects.equals(maSach, that.maSach);
    }

    @Override
    public int hashCode() {
        return Objects.hash(maPhieu, maSach);
    }
}
