package com.library.entity;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "PhieuMuon")
public class PhieuMuon {
    @Id
    @Column(name = "MaPhieu", length = 10)
    private String maPhieu;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "MaDG", nullable = false)
    private DocGia docGia;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "MaNV", nullable = false)
    private NhanVien nhanVien;

    @Temporal(TemporalType.DATE)
    @Column(name = "NgayMuon")
    private Date ngayMuon = new Date();

    @OneToMany(mappedBy = "phieuMuon", cascade = CascadeType.ALL)
    private List<ChiTietPhieuMuon> chiTietList;

    public PhieuMuon() {}

    public String getMaPhieu() { return maPhieu; }
    public void setMaPhieu(String maPhieu) { this.maPhieu = maPhieu; }
    public DocGia getDocGia() { return docGia; }
    public void setDocGia(DocGia docGia) { this.docGia = docGia; }
    public NhanVien getNhanVien() { return nhanVien; }
    public void setNhanVien(NhanVien nhanVien) { this.nhanVien = nhanVien; }
    public Date getNgayMuon() { return ngayMuon; }
    public void setNgayMuon(Date ngayMuon) { this.ngayMuon = ngayMuon; }
    public List<ChiTietPhieuMuon> getChiTietList() { return chiTietList; }
    public void setChiTietList(List<ChiTietPhieuMuon> chiTietList) { this.chiTietList = chiTietList; }
}
